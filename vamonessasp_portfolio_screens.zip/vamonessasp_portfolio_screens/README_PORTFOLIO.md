# Vamo Nessa SP — screenshots para o portfólio

## Sequência recomendada

### 01 — Visão geral
Arquivo: `01_visao-geral_dashboard.png`

**Uso:** principal imagem do case.  
**Onde:** logo após o hero ou como primeira imagem grande.

**O que comunica:** que não é apenas um dashboard de vaidade. O sistema reúne crescimento, conteúdo, aquisição e operação em uma única visão.

**Copy curta sugerida:**
> Uma operação de conteúdo inteira em uma única visão.

**Prioridade:** ESSENCIAL

---

### 02 — Aquisição / Social Selling
Arquivo: `02_aquisicao_social-selling.png`

**Uso:** explicar a camada de aquisição e automação.

**Onde:** seção sobre Social Selling / Intelligent Operations.

**O que comunica:** o sistema identifica pessoas que interagiram, aplica regras de elegibilidade e permite transformar interação em contato via Direct.

**Copy curta sugerida:**
> Interações deixam de ser apenas engajamento e passam a virar oportunidades.

**Prioridade:** ESSENCIAL

---

### 03 — Conteúdos / Performance multicanal
Arquivo: `03_conteudos_performance_multicanal.png`

**Uso:** mostrar a camada analítica do produto.

**Onde:** seção sobre inteligência de conteúdo ou logo depois da visão geral.

**O que comunica:** consolidação de desempenho por publicação e por plataforma, permitindo comparar conteúdos e entender o que realmente performa.

**Copy curta sugerida:**
> Cada conteúdo comparado pelo que realmente entregou.

**Prioridade:** ESSENCIAL

---

### 04 — Crescimento após publicação
Arquivo: `04_crescimento_pos-publicacao.png`

**Uso:** provar que o painel vai além de views.

**Onde:** seção de análise de crescimento, como imagem secundária.

**O que comunica:** acompanhamento do crescimento da conta em janelas após cada publicação, sem prometer atribuição causal que a API não fornece.

**Copy curta sugerida:**
> Conteúdo e crescimento analisados no mesmo contexto.

**Prioridade:** ALTA

---

### 05 — Comentários / Oportunidades
Arquivo: `05_comentarios_oportunidades.png`

**Uso:** detalhar a operação de comentários e elegibilidade.

**Onde:** perto da seção de automação, apenas se o case tiver espaço.

**O que comunica:** identificação de comentários elegíveis, fila de envio e acompanhamento operacional.

**Copy curta sugerida:**
> O sistema separa interação de oportunidade.

**Prioridade:** MÉDIA  
**Observação:** pode ser removida se o case ficar longo, pois a tela de Aquisição já explica parte desta lógica.

---

### 06 — Frequência editorial
Arquivo: `06_frequencia_editorial.png`

**Uso:** mostrar análise de consistência e frequência.

**Onde:** seção de inteligência editorial, se existir.

**O que comunica:** comparação entre frequência de publicação, desempenho e crescimento.

**Copy curta sugerida:**
> Frequência deixa de ser sensação e passa a ser dado.

**Prioridade:** BAIXA/MÉDIA  
**Observação:** bom detalhe de produto, mas não é uma das telas que mais vende a capacidade técnica da Ergon.

---

### 07 — Campanhas
Arquivo: `07_campanhas_diretas.png`

**Uso:** mostrar execução real de campanhas de aquisição.

**Onde:** depois da tela de Aquisição ou em uma composição com ela.

**O que comunica:** criação e acompanhamento de disparos, fila, enviados, erros e progresso de campanhas.

**Copy curta sugerida:**
> Da identificação da oportunidade até o envio da campanha.

**Prioridade:** ALTA

---

### 08 — Aprovações com IA
Arquivo: `08_aprovacoes_ia.png`

**Uso:** mostrar a camada humana + IA.

**Onde:** seção sobre automação assistida / revisão de respostas.

**O que comunica:** respostas sugeridas podem ser revisadas, editadas, aprovadas ou descartadas antes do envio.

**Copy curta sugerida:**
> IA para ganhar escala, com controle humano quando necessário.

**Prioridade:** ESSENCIAL

---

# Seleção enxuta para o case

Se o portfólio tiver que ser curto, eu usaria apenas estas 5:

1. `01_visao-geral_dashboard.png`
2. `02_aquisicao_social-selling.png`
3. `03_conteudos_performance_multicanal.png`
4. `08_aprovacoes_ia.png`
5. `07_campanhas_diretas.png`

Essas cinco contam a história completa:

**dados → conteúdo → oportunidade → IA → execução**

As imagens 04, 05 e 06 podem entrar como apoio se o layout tiver espaço.

---

# Narrativa sugerida do case

## Hero
**Vamo Nessa SP**  
Uma plataforma própria para transformar conteúdo, audiência e interações em uma operação baseada em dados.

Usar `01_visao-geral_dashboard.png`.

## Inteligência de conteúdo
A plataforma consolida desempenho por publicação e por canal para mostrar o que realmente está funcionando.

Usar `03_conteudos_performance_multicanal.png`.

## Crescimento
O sistema acompanha a evolução da conta e cruza temporalmente crescimento com publicações.

Usar `04_crescimento_pos-publicacao.png` se houver espaço.

## Aquisição
Comentários e menções passam por regras de elegibilidade para identificar novas oportunidades de contato.

Usar `02_aquisicao_social-selling.png`.

## Automação assistida
Respostas podem ser geradas, revisadas, editadas e aprovadas antes do envio.

Usar `08_aprovacoes_ia.png`.

## Campanhas
As oportunidades podem ser organizadas em campanhas com acompanhamento de fila, envios e erros.

Usar `07_campanhas_diretas.png`.

---

# Direção para o layout

- Não usar as 8 telas uma embaixo da outra.
- Priorizar screenshots grandes.
- Alternar imagem full-width com blocos de duas imagens apenas quando fizer sentido.
- Não colocar molduras artificiais de notebook/celular. Os screenshots já mostram o produto.
- Evitar textos longos ao lado das imagens.
- Cada tela deve provar uma capacidade específica.
- A tela de Visão Geral deve ser a imagem mais importante.
- Aquisição + Aprovações são as telas que melhor ajudam a vender a Ergon como Digital Product Studio, e não apenas como criadora de sites.

Quando o print do portfólio atual for enviado, ajustar a posição exata de cada tela ao layout existente.
